/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;

/**
// *
 * @author User
 */
abstract class Cucian {
    private int TotalHarga;

    public Cucian(int TotalHarga) {
        this.TotalHarga =  TotalHarga;
    }

    public int getTotalHarga() {
        return TotalHarga;
    }

    
 
    
    
    

    
    
    
}
